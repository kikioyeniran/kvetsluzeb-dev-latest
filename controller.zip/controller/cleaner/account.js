'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _express = require('express');

var _bodyParser = require('body-parser');

var _bodyParser2 = _interopRequireDefault(_bodyParser);

var _jsonwebtoken = require('jsonwebtoken');

var _jsonwebtoken2 = _interopRequireDefault(_jsonwebtoken);

var _bcryptjs = require('bcryptjs');

var _bcryptjs2 = _interopRequireDefault(_bcryptjs);

var _multer = require('multer');

var _multer2 = _interopRequireDefault(_multer);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _dateAndTime = require('date-and-time');

var _dateAndTime2 = _interopRequireDefault(_dateAndTime);

var _utils = require('../../utils');

var _config = require('../../config');

var _config2 = _interopRequireDefault(_config);

var _email = require('../../util/email');

var _email2 = _interopRequireDefault(_email);

var _isEmpty = require('is-empty');

var _isEmpty2 = _interopRequireDefault(_isEmpty);

var _cleaner = require('../../model/cleaner/cleaner');

var _cleaner2 = _interopRequireDefault(_cleaner);

var _cleanerDetails = require('../../model/cleaner/cleanerDetails');

var _cleanerDetails2 = _interopRequireDefault(_cleanerDetails);

var _clientDetails = require('../../model/client/clientDetails');

var _clientDetails2 = _interopRequireDefault(_clientDetails);

var _requests = require('../../model/booking/requests');

var _requests2 = _interopRequireDefault(_requests);

var _cleaningSchedule = require('../../model/cleaningSchedule');

var _cleaningSchedule2 = _interopRequireDefault(_cleaningSchedule);

var _cleanerWallet = require('../../model/cleaner/cleanerWallet');

var _cleanerWallet2 = _interopRequireDefault(_cleanerWallet);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//  Sending mails


// destructuring the validate token method
var mailgun = require("mailgun-js");
var DOMAIN = 'kvetsluzeb.com';
var api_key = '3896a986c536ba4c44b6278b43417c4a-2ae2c6f3-9188bee6';
var mg = mailgun({ apiKey: api_key, domain: DOMAIN, host: 'api.eu.mailgun.net' });

// importing the models

exports.default = function (_ref) {
    var config = _ref.config,
        db = _ref.db;

    var api = (0, _express.Router)();

    // ******************************************
    // ******* CLEANER AUTHENTICATION ***********
    // ******************************************

    // '/api/v1/account/cleaner/signup'
    api.post('/signup', function (req, res) {
        // console.log('submitted');
        // Set The Storage Engine
        var storage = _multer2.default.diskStorage({
            destination: './public/uploads/',
            filename: function filename(req, file, cb) {
                cb(null, file.fieldname + '-' + Date.now() + _path2.default.extname(file.originalname));
            }
        });

        function checkFileType(files, cb) {
            // Allowed ext
            var filetypes = /jpeg|jpg|png|gif|pdf/;
            // Check ext
            var extname = filetypes.test(_path2.default.extname(files.originalname).toLowerCase());
            // Check mime
            var mimetype = filetypes.test(files.mimetype);

            if (mimetype && extname) {
                return cb(null, true);
            } else {
                cb('Error: Images and Documents Only!');
            }
        }
        // Initialise Upload
        var upload = (0, _multer2.default)({
            storage: storage,
            limits: { fileSize: 10000000 },
            fileFilter: function fileFilter(req, file, cb) {
                checkFileType(file, cb);
            }
        }).fields([{ name: 'profilePic' }, { name: 'nationalID' }, { name: 'healthInsurance' }]);

        upload(req, res, function (err) {
            if (err) {
                var result = {};
                var status = 400;
                result.status = status;
                result.error = err;
                res.status(status).send(result);
                // console.log(err);
            } else {
                // const username = req.body.username.toLowerCase();
                var email = req.body.email;
                var password = req.body.password;
                var password2 = req.body.password2;

                var postcode = req.body.postcode;
                var extraTasks = req.body.extraTasks;
                var experience = req.body.experience;
                var profile = req.body.profile;
                var fullName = req.body.fullname;
                var mobileNumber = req.body.mobilenumber;
                var address = req.body.address;
                var city = req.body.city;
                var country = req.body.country;
                var income = req.body.income;
                var cleanerID = _bcryptjs2.default.hashSync('fullName', 10);
                var profilePic = req.files['profilePic'][0].filename;
                var nationalID = req.files['nationalID'][0].filename;
                var healthInsurance = req.files['healthInsurance'][0].filename;
                //const cleanerID = req.body._id;

                req.checkBody('email', 'Email is required').notEmpty();
                req.checkBody('email', 'Email is not valid').isEmail();
                req.checkBody('password', 'Password is required').notEmpty();
                req.checkBody('password2', 'Passwords do not match').equals(req.body.password);
                req.checkBody('postcode', 'Postcode is required').notEmpty();
                req.checkBody('fullname', 'Your Full Name  is not valid').notEmpty();
                req.checkBody('mobilenumber', 'Mobile Number is required').notEmpty();
                req.checkBody('address', 'Addresss is required').notEmpty();
                req.checkBody('city', 'City is required').notEmpty();
                req.checkBody('country', 'Country is required').notEmpty();
                req.checkBody('income', 'Your desired income is required').notEmpty();
                req.checkBody('experience', 'Your years of experience is required').notEmpty();
                req.checkBody('profile', 'Your profile is required').notEmpty();
                // req.checkBody('nationalID', 'Your means of identification is required').notEmpty();
                // req.checkBody('healthInsurance', 'Your Health Insurance is required').notEmpty();

                var errors = req.validationErrors();

                var _status = 200;
                var _result = {};

                if (errors) {
                    _status = 400;
                    _result.error = errors;
                    _result.status = _status;
                    res.status(_status).send(_result);
                } else {
                    var newUser = new _cleaner2.default({
                        email: email,
                        cleanerID: cleanerID,
                        password: password
                    });
                    var newUserDetails = new _cleanerDetails2.default({
                        postcode: postcode,
                        mobileNumber: mobileNumber,
                        extraTasks: extraTasks,
                        experience: experience,
                        profile: profile,
                        profilePic: profilePic,
                        nationalID: nationalID,
                        healthInsurance: healthInsurance,
                        address: address,
                        fullName: fullName,
                        city: city,
                        country: country,
                        income: income,
                        cleanerID: cleanerID
                    });
                    var newCleanerWallet = new _cleanerWallet2.default({
                        cleanerID: cleanerID,
                        cleanerIncome: income
                    });
                    _bcryptjs2.default.genSalt(10, function (err, salt) {
                        _bcryptjs2.default.hash(newUser.password, salt, function (err, hash) {
                            if (err) {
                                statusCode = 500;
                                var _error = err;
                                _result.status = _status;
                                _result.error = _error;
                                res.status(statusCode).send(_result);
                                console.log(err);
                            }
                            //console.log('bcrypt stage reached');
                            newUser.password = hash;
                            newUser.save(function (err) {

                                var result = {};
                                var status = 200;
                                if (err) {
                                    status = 400;
                                    result.status = status;
                                    result.error = err;
                                    res.status(status).send(result);
                                } else {
                                    newUserDetails.save(function (err) {
                                        var result = {};
                                        var status = 200;
                                        if (err) {
                                            status = 400;
                                            result.status = status;
                                            result.error = err;
                                            res.status(status).send(result);
                                        } else {
                                            newCleanerWallet.save(function (err) {
                                                var result = {};
                                                var status = 200;
                                                if (err) {
                                                    status = 400;
                                                    result.status = status;
                                                    result.error = err;
                                                    res.status(status).send(result);
                                                } else {
                                                    result.status = status;
                                                    result.message = 'Successfully Created A Cleaner Account & Uploaded pictures';
                                                    res.status(status).send(result);
                                                }
                                            });
                                        }
                                    });
                                }
                            });
                        });
                    });
                }
            }
        });
    });

    // '/api/v1/account/cleaner/login'
    api.post('/login', function (req, res) {
        var result = {};
        var status = 200;

        var _req$body = req.body,
            email = _req$body.email,
            password = _req$body.password;

        _cleaner2.default.findOne({ email: email }, function (err, user) {
            if (!err && user) {
                // if there is no error and a user is found
                _bcryptjs2.default.compare(password, user.password).then(function (match) {
                    if (match) {
                        status = 200;

                        // creating the user token
                        // const payload = { user: user.name};
                        var payload = { _id: user._id };

                        var options = { expiresIn: '1d', issuer: 'http://relicinnova.com.ng' };
                        var secret = config.secret;
                        var token = _jsonwebtoken2.default.sign(payload, secret, options);

                        // printing the token
                        result.token = token;
                        result.user = user;
                        result.status = status;

                        // res.status(status).send(result);
                    } else {
                        status = 400;
                        result = error = 'Authentication error';
                        // res.status(status).send(result);
                    }
                    res.status(status).send(result);
                }).catch(function (err) {
                    status = 500;
                    result.status = status;
                    result.error = err;
                    res.status(status).send(result);
                });
            } else {
                status = 404;
                var message = 'Incorrect email or password';
                result.status = status;
                result.error = err;
                result.message = message;
                res.status(status).send(result);
            }
        });
    });

    // '/api/v1/account/cleaner/passwordUpdate/:id'
    api.patch('/passwordUpdate/:id', _utils.validateToken, function (req, res) {
        // get user from collection
        _cleaner2.default.findById(req.id, function (err, user) {
            if (err) {
                res.send(err);
            } else if (!user.correctPassword(req.body.passwordCurrent, user.password)) {
                res.status(404).send('Your current password is wrong.');
            }
        });

        user.password = req.body.password;
        user.passwordConfirm = req.body.passwordConfirm;

        user.save(function (err) {
            if (err) {
                res.status(404).send(err);
            }
            res.status(201).json({
                message: 'Successfull'
            });
        });
    });

    // '/api/v1/account/cleaner/forgotPassword'
    api.post('/forgotPassword', function (req, res) {
        // get user based on posted email
        _cleaner2.default.findOne({ email: req.body.email }, function (err, user) {

            var status = 200;
            var result = {};

            // console.log(req.body.email);
            if (err) {
                status = 404;
                result.status = status;
                result.error = err;
                res.status(status).send(result);
            }
            // generate random token

            var resetToken = user.createPasswordResetToken();
            // await user.save()
            user.save({ validateBeforeSave: false });

            var resetUrl = req.protocol + '://' + req.get('host') + '/client/pswd/resetpswd/' + resetToken;
            var msg = '<strong>Forgot Password?</strong> Please click this link and enter your new password: ' + resetUrl + '.\n If you didnt forget your password, please ignore this email!';
            var data = {
                from: 'Kvet Sluzeb (Bloom Services) <support@kvetsluzeb.com>',
                to: req.body.email,
                subject: 'Password Reset Token',
                text: msg,
                html: msg
            };
            mg.messages().send(data, function (error, body) {
                if (error) {
                    // console.log(error)
                    status = 404;
                    result.status = status;
                    result.error = error;
                    // result.message = ''
                    res.status(status).send(result);
                    //   res.render('client/forgotpswd', {
                    //     clientID: user._id,
                    //     message: 'Please make sure you entered the right password'
                    // })
                } else {
                    status = 200;
                    result.status = status;
                    result.message = 'The password reset token has been sent to your mail';
                    // result.message = ''
                    res.status(status).send(result);
                }
            });
        });
    });
    // '/api/v1/account/cleaner/resetPassword/:token'
    api.patch('/resetPassword/:token', function (req, res) {
        // get user based on the token
        var hashedToken = crypto.createHash('sha256').update(req.params.token).digest('hex');
        // const user =
        _cleaner2.default.findOne({ passwordResetToken: hashedToken, passwordResetExpires: { $gt: Date.now() } }, function (err, user) {
            if (err) {
                res.status(404).send(err);
            }

            user.password = req.body.password;
            user.password2 = req.body.password2;
            user.passwordResetToken = undefined;
            user.passwordResetExpires = undefined;

            user.save(function (err) {
                if (err) {
                    res.status(200).send(err);
                }
                res.status(201).json({
                    message: 'Successful'
                });
            });

            //  Redirect the user to login
        });
        // if token has not expired and user exists we set the new password
    });

    // /api/v1/account/cleaner/login/passwordChange/:id
    api.post('/passwordChange/:id', _utils.validateToken, function (req, res) {
        // get user from collection
        _cleaner2.default.findById(req.params.id, function (err, user) {
            var result = {};
            var status = 200;
            if (err) {
                status = 404;
                result.status = status;
                result.error = err;
                res.status(status).send(result);
                return;
            } else {
                //Check Old Password
                _bcryptjs2.default.compare(req.body.passwordCurrent, user.password, function (err, match) {
                    if (!match) {
                        status = 400;
                        result.status = status;
                        result.message = 'Your current password is incorrect. Please try again';
                        res.status(status).send(result);
                    } else {
                        //Password Match
                        var password = req.body.password;
                        var passwordConfirm = req.body.passwordConfirm;
                        // console.log(password, passwordConfirm);
                        req.checkBody('password', 'Password is required').notEmpty();
                        req.checkBody('passwordConfirm', 'Passwords do not match').equals(req.body.password);
                        var errors = req.validationErrors();

                        if (errors) {
                            status = 400;
                            result.status = status;
                            result.error = errors;
                            res.status(status).send(result);

                            return;
                        } else {
                            user.password = password;
                            // user.passwordConfirm = passwordConfirm;
                            _bcryptjs2.default.genSalt(10, function (err, salt) {
                                _bcryptjs2.default.hash(user.password, salt, function (err, hash) {
                                    if (err) {
                                        status = 500;
                                        result.status = status;
                                        result.error = err;
                                        res.status(status).send(result);
                                    }
                                    user.password = hash;
                                    user.save(function (err) {
                                        if (err) {
                                            status = 400;
                                            result.status = status;
                                            result.error = err;
                                            res.status(status).send(result);
                                        } else {
                                            status = 201;
                                            result.status = status;
                                            result.message = 'Password updated Successfully';
                                            res.status(status).send(result);
                                        }
                                    });
                                });
                            });
                        }
                    }
                });
            }
        });
    });

    // '/api/v1/account/cleaner/logout'
    api.get('/logout', function (req, res) {
        req.logout();
        var result = {};
        var status = 201;
        result.status = status;
        result.message = 'Successfully logged out';
        res.status(status).send(result);
    });

    // ********************************************
    // ******* CLEANER PROFILE SETTINGS ***********
    // ********************************************

    // '/api/v1/account/cleaner/profile/:cleanerID/:id'
    api.post('/profile/:cleanerID/:id/', _utils.validateToken, function (req, res) {
        var statusCode = 200;
        var result = {};

        var cleaner = {};
        cleaner.fullName = req.body.fullName;
        //console.log(req.body.fullName);
        cleaner.postcode = req.body.postcode;
        cleaner.city = req.body.city;
        cleaner.country = req.body.country;
        cleaner.address = req.body.address;
        cleaner.mobileNumber = req.body.mobileNumber;
        cleaner.extraTasks = req.body.extraTasks;
        cleaner.profile = req.body.profile;
        cleaner.income = req.body.income;
        var query = { cleanerID: req.params.cleanerID
            //console.log(query);
            //console.log(req.params.cleanerID)

        };_cleanerDetails2.default.updateOne(query, cleaner, function (err) {
            if (err) {
                result.statusCode = 401;
                result.error = err;
                res.status(statusCode).send(result);
            } else {
                result.statusCode = statusCode;
                result.message = 'Found and updated Cleaner Profile';
                res.status(statusCode).send(result);

                // console.log('found and updated');
                // req.flash('success', 'Account Updated');
                // res.redirect('/cleaner/dashboard/home/'+req.params.id);
            }
        });
    });

    // **************************************
    // ******* CLEANER DASHBOARD  ***********
    // **************************************

    // '/api/v1/account/cleaner/home/:id'
    api.get('/home/:id', _utils.validateToken, function (req, res) {
        _cleaner2.default.findById(req.params.id, function (err, cleaner) {
            //console.log(cleaner)
            var query = { cleanerID: cleaner.cleanerID };
            _cleanerDetails2.default.find(query, function (err, cleaner_details) {
                //console.log(cleaner_details[0].fullName);
                var result = {};
                var statusCode = 201;

                if (err) {
                    result.status = 404;
                    result.error = err;
                    res.status(statusCode).send(result);
                }
                result.statusCode = statusCode;
                result.user = cleaner_details[0];
                res.status(statusCode).send(result);
            });
        });
    });

    api.get('/wallet/:id', _utils.validateToken, function (req, res) {
        _cleaner2.default.findById(req.params.id, function (err, cleaner) {
            //console.log(cleaner)
            var result = {};
            var statusCode = 200;
            var query = { cleanerID: cleaner.cleanerID };
            _cleanerDetails2.default.find(query, function (err, cleaner_details) {
                //console.log(cleaner_details);
                _cleanerWallet2.default.findOne(query, function (err, wallet) {
                    // console.log(cleaner.cleanerID);
                    // console.log(wallet);

                    if (err) {
                        result.statusCode = 404;
                        result.error = err;
                        res.status(statusCode).send(result);
                    }
                    result.statusCode = statusCode;
                    result.userDetails = cleaner_details[0];
                    result.wallet = wallet;
                    res.status(statusCode).send(result);
                });
            });
        });
    });

    api.get('/cleanerInvoice/:id', _utils.validateToken, function (req, res) {
        _cleaner2.default.findById(req.params.id, function (err, cleaner) {
            var result = {};
            var statusCode = 201;
            console.log(cleaner);
            var query = { cleanerID: cleaner.cleanerID };
            _cleanerDetails2.default.find(query, function (err, cleaner_details) {
                if (err) {
                    result.statusCode = 404;
                    result.error = err;
                    res.status(statusCode).send(result);
                }
                result.statusCode = statusCode;
                result.user = cleaner_details[0];
                res.status(statusCode).send(result);
            });
        });
    });

    api.get('/cleanerRequests/:id', _utils.validateToken, function (req, res) {
        var result = {};
        var statusCode = 201;
        _cleaner2.default.findById(req.params.id, function (err, cleaner) {
            //console.log(cleaner)
            var query = { cleanerID: cleaner.cleanerID };
            _cleanerDetails2.default.find(query, function (err, cleaner_details) {
                var secondQuery = { selectedcleanerIDs: cleaner.cleanerID };
                console.log(secondQuery);
                _requests2.default.find(secondQuery).sort('-updated').exec(function (err, request) {
                    if ((0, _isEmpty2.default)(request)) {
                        result.statusCode = statusCode;
                        result.user = cleaner;
                        result.requests = null;
                        result.userDetails = cleaner_details[0];
                        res.status(statusCode).send(result);
                    } else {

                        result.statusCode = statusCode;
                        result.user = cleaner;
                        result.requests = request;
                        result.userDetails = cleaner_details[0];
                        res.status(statusCode).send(result);
                    }
                });
                // Requests.find((secondQuery), (err, request)=>{

                // })
            });
        });
    });

    api.get('/cleanerCalendar/:id', _utils.validateToken, function (req, res) {
        _cleaner2.default.findById(req.params.id, function (err, cleaner) {
            //console.log(req.params.id);
            var result = {};
            var statusCode = 200;
            var query = { cleanerID: cleaner.cleanerID };
            _cleanerDetails2.default.find(query, function (err, cleaner_details) {
                var query2 = { cleanerID: req.params.id };
                _cleaningSchedule2.default.find(query2).populate('clientDetails').exec(function (err, schedule) {
                    if (err) {
                        statusCode = 400;
                        result.statusCode = statusCode;
                        result.error = err;
                        res.status(statusCode).send(result);
                    } else {
                        // console.log(schedule[0].clientDetails.length);
                        //console.log(Object.keys(schedule));
                        if ((0, _isEmpty2.default)(schedule)) {
                            //console.log('here');
                            result.statusCode = 400;
                            result.user = cleaner;
                            result.userDetails = cleaner_details[0];
                            result.schedules = null;
                            res.status(statusCode).send(result);
                        } else {
                            _cleaningSchedule2.default.countDocuments(query2, function (err, c) {
                                //console.log('Count is ' + c);
                                var count = c;
                                var newArray = [];

                                //console.log(typeof(count));
                                for (var i = 0; i < count; i++) {
                                    var newObject = {};
                                    var tempSchedule = schedule[i];
                                    console.log(tempSchedule);
                                    var firstClean = false;
                                    if ((0, _isEmpty2.default)(tempSchedule.lastClean)) {
                                        firstClean = true;
                                    } else {
                                        var lastCleanDate = tempSchedule.lastClean[0].lastCleanDate;
                                        var lastCleanDate = new Date(lastCleanDate);
                                        var lastCleanDate = _dateAndTime2.default.format(lastCleanDate, 'ddd, MMM DD YYYY');
                                        var lastCleanStatus = tempSchedule.lastClean[0].cleanStatus;
                                        var lastPaidStatus = tempSchedule.lastClean[0].paidStatus;
                                        console.log(tempSchedule.lastClean[0].lastCleanDate);
                                    }
                                    var currentCleanDate = tempSchedule.currentClean[0].currentCleanDate;
                                    var currentCleanDate = new Date(currentCleanDate);
                                    var currentCleanDate = _dateAndTime2.default.format(currentCleanDate, 'ddd, MMM DD YYYY');
                                    var nextCleanDate = tempSchedule.currentClean[0].nextCleanDate;
                                    var nextCleanDate = new Date(nextCleanDate);
                                    var nextCleanDate = _dateAndTime2.default.format(nextCleanDate, 'ddd, MMM DD YYYY');
                                    newObject.currentCleanDate = currentCleanDate;
                                    newObject.lastCleanDate = lastCleanDate;

                                    newObject.nextCleanDate = nextCleanDate;
                                    newObject.clientDetails = tempSchedule.clientDetails;
                                    newObject.lastCleanStatus = lastCleanStatus;
                                    newObject.lastPaidStatus = lastPaidStatus;
                                    newArray.push(newObject);
                                    //console.log(tempSchedule.clientDetails);
                                }
                                //console.log(newArray[0].lastCleanDate[0].cleanStatus);
                                // res.render('cleaner/cleaner_calendar',{
                                //     cleaner: cleaner,
                                //     firstClean: firstClean,
                                //     //clients: newObject.clientDetails,
                                //     cleanerDetails: cleaner_details[0],
                                //     schedules: newArray,
                                //     scheduleID: schedule[0]._id
                                // });z

                                result.statusCode = statusCode;
                                result.user = cleaner;
                                result.firstClean = firstClean;
                                result.userDetails = cleaner_details[0];
                                result.schedules = newArray;
                                result.scheduleID = schedule[0]._id;
                                res.status(statusCode).send(result);
                            });
                        }
                    }
                });
            });
        });
    });

    api.get('/cleanerFaq/:id', _utils.validateToken, function (req, res) {
        _cleaner2.default.findById(req.params.id, function (err, cleaner) {
            console.log(cleaner);
            var query = { cleanerID: cleaner.cleanerID };
            _cleanerDetails2.default.find(query, function (err, cleaner_details) {
                //console.log(cleaner_details[0].fullName);
                var result = {};
                var statusCode = 200;
                if (err) {
                    statusCode = 400;
                    result.statusCode = statusCode;
                    result.error = err;
                    res.status(statusCode).send(result);
                }
                result.user = cleaner;
                result.userDetails = cleaner_details[0];
                result.statusCode = statusCode;

                res.status(statusCode).send(result);
            });
        });
    });
    // **********************************************
    // ******* GET CLEANER RATING *************
    // **********************************************
    api.get('/cleanerRating/:id', _utils.validateToken, function(req, res){
        _cleaner2.default.findById(req.params.id, function (err, cleaner) {
            //console.log(cleaner)
            var query = { cleanerID: cleaner.cleanerID };
            _cleanerDetails2.default.find(query, function (err, cleaner_details) {
                //console.log(cleaner_details[0].fullName);
                var result = {};
                var statusCode = 201;

                if (err) {
                    result.status = 404;
                    result.error = err;
                    res.status(statusCode).send(result);
                }
                result.statusCode = statusCode;
                result.user = cleaner_details[0];
                result.rating = cleaner_details[0].rating;
                res.status(statusCode).send(result);
            });
        });
    })

    // **********************************************
    // ******* CANCEL CLEANING SCHEDULE *************
    // **********************************************
    api.get('/:scheduleID/:cleanerID/:clientID', function (req, res) {
        const {scheduleID, cleanerID, clientID} = req.params;
        var result = {};
        var statusCode = 200;
        _cleaningSchedule2.default
            .findById(scheduleID)
            .populate('clientDetails')
            .exec((err, schedule)=>{
            if(err){
                console.log(err)
            }
            else{
                let cancelUpdate = {};
                var dblastClean = schedule.lastClean[0];
                var dbcurrentClean = schedule.currentClean[0];
                var incremental = schedule.currentClean[0].incremental;
                var newCurrentDate = schedule.currentClean[0].nextCleanDate;
                var nextCleanDate = new Date().setDate(newCurrentDate.getDate() + incremental);
                var nextCleanDate = new Date(nextCleanDate);
                var clientMail = schedule.clientDetails[0].email;
                // console.log(schedule.clientDetails[0].email)

                var msg = `<strong>Your cleaning Schedule has just been cancelled</strong> by your cleaner. Please contact you client for clarity on this change of plans and for a reschedule. Sorry for the inconvenience. <br/> Regards. <br/>Kvet Sluzeb Team`
                var data = {
                    from: 'Kvet Sluzeb <info@kvetsluzeb.com>',
                    to: clientMail,
                    subject: 'Schedule Changes',
                    text: msg,
                    html: msg
                };
                mg.messages().send(data, function (error, body) {
                    if(error){
                        console.log(error);
                    }
                    else{
                        var lastClean = [{
                            cleanStatus : false,
                            paidStatus : false,
                            cancelStatus : true,
                            lastCleanDate  : dbcurrentClean.currentCleanDate
                        }];
                        var currentClean = [{
                            cleanStatus : true,
                            paidStatus : false,
                            cancelStatus : false,
                            currentCleanDate  : newCurrentDate,
                            nextCleanDate: nextCleanDate,
                            incremental: incremental
                        }]
                        //console.log(lastClean, ' ', currentClean);
                        cancelUpdate.lastClean = lastClean;
                        cancelUpdate.currentClean = currentClean;
                        var newLastCleanDate = dbcurrentClean.currentCleanDate;
                        console.log(newLastCleanDate);
                        var query = {_id: scheduleID};
                        _cleaningSchedule2.default.updateOne(query, cancelUpdate, (err) =>{
                            if (err) {
                                result.error = err;
                                result.statusCode = 404;
                                res.status(statusCode).send(result);
                            } else {
                                //console.log('wallet found and updated');
                                //req.flash('success', 'Account Updated');
                                var message = 'Schedule Canceled succesfully. Please redirect to User dashboard';

                                result.error = err;
                                result.statusCode = statusCode;
                                result.message = message;
                                res.status(statusCode).send(result);
                                // res.redirect('/cleaner/dashboard/cleaner_calendar/'+cleanerID);
                            }
                        });
                    }
                });
            }
        });
    });

    // **********************************************
    // ******* GET CLEANER RATING *************
    // **********************************************

    return api;
};
//# sourceMappingURL=account.js.map