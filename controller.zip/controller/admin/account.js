'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _express = require('express');

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _bcryptjs = require('bcryptjs');

var _bcryptjs2 = _interopRequireDefault(_bcryptjs);

var _admin = require('../../model/admin/admin');

var _admin2 = _interopRequireDefault(_admin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var sendEmail = require('../../util/email');

exports.default = function (_ref) {
    var config = _ref.config,
        db = _ref.db;

    var api = (0, _express.Router)();

    //Register Processes
    api.post('/signup', function (req, res) {
        var username = req.body.username;
        var password = req.body.password;
        var password2 = req.body.password2;

        req.checkBody('username', 'username is required').notEmpty();
        //req.checkBody('username', 'Email is not valid').isEmail();
        req.checkBody('password', 'Password is required').notEmpty();
        req.checkBody('password2', 'Passwords do not match').equals(req.body.password);

        var errors = req.validationErrors();

        if (errors) {
            var _status = 400;
            var _result = {};
            var _error = errors;
            _result.status = _status;
            _result.error = _error;
            res.status(_status).send(_result);
        } else {
            var newUser = new _admin2.default({
                username: username,
                password: password
            });
            _bcryptjs2.default.genSalt(10, function (err, salt) {
                _bcryptjs2.default.hash(newUser.password, salt, function (err, hash) {
                    if (err) {
                        console.log(err);
                    }
                    newUser.password = hash;
                    newUser.save(function (err) {
                        if (err) {
                            var _status2 = 400;
                            var _result2 = {};
                            var _error2 = err;
                            _result2.status = _status2;
                            _result2.error = _error2;
                            res.status(_status2).send(_result2);
                        } else {
                            var _status3 = 200;
                            var _result3 = {};
                            var _message = 'You are now registered and can login';
                            _result3.status = _status3;
                            _result3.error = error;
                            res.status(_status3).send(_result3);
                        }
                    });
                });
            });
        }
    });

    // '/api/v1/account/admin/login'        
    api.post('/login', function (req, res) {
        var result = {};
        var status = 200;

        var _req$body = req.body,
            email = _req$body.email,
            password = _req$body.password;

        _admin2.default.findOne({ email: email }, function (err, user) {
            if (!err && user) {
                // if there is no error and a user is found 
                _bcryptjs2.default.compare(password, user.password).then(function (match) {
                    if (match) {
                        status = 200;

                        // creating the user token
                        // const payload = { user: user.name};
                        var payload = { _id: user._id };

                        var options = { expiresIn: '1d', issuer: 'http://relicinnova.com.ng' };
                        var secret = config.secret;
                        var token = jwt.sign(payload, secret, options);

                        // printing the token 
                        result.token = token;
                        result.user = user;
                        result.status = status;

                        res.status(status).send(result);
                    } else {
                        status = 400;
                        result = error = 'Authentication error';
                        res.status(status).send(result);
                    }
                }).catch(function (err) {
                    status = 500;
                    result.status = status;
                    result.error = err;
                    res.status(status).send(result);
                });
            } else {
                status = 400;
                message = 'Incorrect email or password';
                result.status = status;
                result.error = err;
                result.message = message;
                res.status(status).send(result);
            }
        });
    });

    // '/api/v1/account/admin/logout'        
    api.get('/logout', function (req, res) {
        req.logout();
        var result = {};
        var status = 201;
        result.status = status;
        result.message = 'Successfully logged out';
        res.status(status).send(result);
    });

    api.post('/forgotPassword', function (req, res) {
        _admin2.default.findOne({ email: req.body.email }, function (err, user) {
            if (err) {
                res.status(404).send(err);
            }
            // generate random token
            var resetToken = user.createPasswordResetToken();
            // await user.save()
            user.save({ validateBeforeSave: false });

            var resetUrl = req.protocol + '://' + req.get('host') + '/admin/pswd/resetpswd/' + resetToken;
            var message = 'Forgot Password? Submit a PATCH request with your new Password and passwordConfirn to: ' + resetUrl + '.\n If you didnt forget your password, please ignore this email!';
            try {
                var _sendEmail = {
                    email: user.email,
                    subject: 'Password Reset Link (Valid for 10Mins)',
                    message: message
                };
                res.status(200).json({
                    status: 'success',
                    message: 'Token sent to mail'
                });
            } catch (err) {
                user.passwordResetToken = undefined;
                user.passwordResetExpires = undefined;
                user.save({ validateBeforeSave: false });
                console.log(err);
            }
        });
    });

    api.patch('/resetPassword/:token', function (req, res) {

        // get user based on the token
        var hashedToken = crypto.createHash('sha256').update(req.params.token).digest('hex');
        // const user =
        _admin2.default.findOne({ passwordResetToken: hashedToken, passwordResetExpires: { $gt: Date.now() } }, function (err, user) {
            if (err) {
                status = 404;
                result.status = status;
                result.error = err;
                res.status(status).send(result);
            }

            user.password = req.body.password;
            user.password2 = req.body.password2;
            user.passwordResetToken = undefined;
            user.passwordResetExpires = undefined;

            user.save(function (err) {
                if (err) {
                    status = 400;
                    result.status = status;
                    result.error = err;
                    res.status(status).send(result);
                } else {
                    status = 404;
                    result.status = status;
                    result.message = 'Password Changed';
                    res.status(status).send(result);
                }
            });

            //  Redirect the user to login
        });
        // if token has not expired and user exists we set the new password
    });

    return api;
};
//# sourceMappingURL=account.js.map