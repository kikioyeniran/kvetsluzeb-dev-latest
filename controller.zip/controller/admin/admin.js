'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _express = require('express');

var _bcryptjs = require('bcryptjs');

var _bcryptjs2 = _interopRequireDefault(_bcryptjs);

var _config = require('../../config');

var _config2 = _interopRequireDefault(_config);

var _client = require('../../model/client/client');

var _client2 = _interopRequireDefault(_client);

var _clientDetails = require('../../model/client/clientDetails');

var _clientDetails2 = _interopRequireDefault(_clientDetails);

var _cleaner = require('../../model/cleaner/cleaner');

var _cleaner2 = _interopRequireDefault(_cleaner);

var _cleanerDetails = require('../../model/cleaner/cleanerDetails');

var _cleanerDetails2 = _interopRequireDefault(_cleanerDetails);

var _admin = require('../../model/admin/admin');

var _admin2 = _interopRequireDefault(_admin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (_ref) {
    var config = _ref.config,
        db = _ref.db;

    var api = (0, _express.Router)();

    // 'api/v1/admin/:id' -- for adding the 
    api.get('/:id', function (req, res) {
        _admin2.default.findById(req.params.id, function (err, admin) {
            var statusCode = 200;
            var result = {};

            if (err) {
                var _statusCode = 400;
                var error = err;
                result.statusCode = _statusCode;
                result.error = error;
                res.status(status).send(result);
            }

            var details = admin;
            result.statusCode = statusCode;
            result.details = details;
            res.status(status).send(result);
        });
    });

    // 'api/v1/admin/clients/:id'
    api.get('/clients/:id', function (req, res) {
        _admin2.default.findById(req.params.id, function (err, admin) {
            var statusCode = 200;
            var result = {};

            if (err) {
                var _statusCode2 = 400;
                var error = err;
                result.statusCode = _statusCode2;
                result.error = error;
                res.status(status).send(result);
            }

            _clientDetails2.default.find({}, function (err, clientDetails) {
                if (err) {
                    var _statusCode3 = 400;
                    var _error = err;
                    result.statusCode = _statusCode3;
                    result.error = _error;
                    res.status(status).send(result);
                }

                // let details = clientDetails;
                // result.statusCode = statusCode;
                // result.details = details;
                // res.status(status).send(result);

                var adminDetails = admin;
                var details = clientDetails;
                result.statusCode = statusCode;
                result.adminDetails = adminDetails;
                result.clientDetails = details;
                res.status(status).send(result);
            });
        });
    });

    // 'api/v1/admin/cleaners/:id'
    api.get('/cleaners/:id', function (req, res) {
        _admin2.default.findById(req.params.id, function (err, admin) {
            var statusCode = 200;
            var result = {};

            if (err) {
                var _statusCode4 = 400;
                var error = err;
                result.statusCode = _statusCode4;
                result.error = error;
                res.status(status).send(result);
            }
            _cleanerDetails2.default.find({}, function (err, cleanerDetails) {
                if (err) {
                    var _statusCode5 = 400;
                    var _error2 = err;
                    result.statusCode = _statusCode5;
                    result.error = _error2;
                    res.status(status).send(result);
                }
                var adminDetails = admin;
                var details = cleanerDetails;
                result.statusCode = statusCode;
                result.adminDetails = adminDetails;
                result.cleanerDetails = details;
                res.status(status).send(result);
            });
        });
    });

    // 'api/v1/admin/singlecleaner/:id/:cleanerID'
    api.get('/singlecleaner/:id/:cleanerID', function (req, res) {
        var statusCode = 200;
        var result = {};
        _admin2.default.findById(req.params.id, function (err, admin) {

            if (err) {
                var _statusCode6 = 400;
                var error = err;
                result.statusCode = _statusCode6;
                result.error = error;
                res.status(status).send(result);
            }
            var adminDetails = admin;
            // let cleaner = cleaner;
            // let details = cleanerDetails;
            // result.statusCode = statusCode;
            // result.details = details;
            // res.status(status).send(result);

            var query = { cleanerID: req.params.cleanerID };
            _cleaner2.default.findOne(query, function (err, cleaner) {

                if (err) {
                    var _statusCode7 = 400;
                    var _error3 = err;
                    result.statusCode = _statusCode7;
                    result.error = _error3;
                    res.status(status).send(result);
                }

                var query = { cleanerID: req.params.cleanerID };
                _cleanerDetails2.default.findOne(query, function (err, cleanerDetails) {
                    if (err) {
                        var _statusCode8 = 400;
                        var _error4 = err;
                        result.statusCode = _statusCode8;
                        result.error = _error4;
                        res.status(status).send(result);
                    }

                    // let admin = admin;
                    // let cleaner = cleaner;
                    var details = cleanerDetails;
                    result.statusCode = statusCode;
                    result.details = details;
                    res.status(status).send(result);
                });
            });
        });
    });

    // 'api/v1/admin/singleclient/:id/:clientid'   
    api.get('/singleclient/:id/:clientid', function (req, res) {
        var statusCode = 200;
        var result = {};

        _admin2.default.findById(req.params.id, function (err, admin) {
            var query = { clientID: req.params.clientid };
            result.adminDetails = admin;
            _client2.default.findOne(query, function (err, client) {
                result.foundClient = client;
                var query = { clientID: req.params.clientid };
                _clientDetails2.default.findOne(query, function (err, clientDetails) {
                    if (err) {
                        var _statusCode9 = 400;
                        var error = err;
                        result.statusCode = _statusCode9;
                        result.error = error;
                        res.status(status).send(result);
                    }
                    var details = clientDetails;
                    result.statusCode = statusCode;
                    result.details = details;
                    res.status(status).send(result);
                });
            });
        });
    });
    // api.get('/singleclient/:id/:clientid', (req, res) => {
    //     let statusCode = 200;
    //     let result = {};
    //     Admin.findById(req.params.id, (err, admin) => {
    //         var query = {clientID: req.params.clientid}

    //         Client.findOne((query), (err, client) => {
    //             var query = {clientID: req.params.clientid}
    //             ClientDetails.findOne((query), (err, clientDetails) => {
    //                 if (err) {
    //                     let statusCode = 400;
    //                     let error = err;
    //                     result.statusCode = statusCode;
    //                     result.error = error;
    //                     res.status(status).send(result);
    //                 }

    //                 // let admin = admin;
    //                 // let cleaner = cleaner;
    //                 let details = clientDetails;
    //                 result.statusCode = statusCode;
    //                 result.details = details;
    //                 res.status(status).send(result);
    //             })
    //         });
    //     });
    // })


    return api;
};

// admin model


// cleaner models 


// client models
//# sourceMappingURL=admin.js.map