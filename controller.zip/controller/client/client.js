'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _express = require('express');

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _config = require('../../config');

var _config2 = _interopRequireDefault(_config);

var _isEmpty = require('is-empty');

var _isEmpty2 = _interopRequireDefault(_isEmpty);

var _utils = require('../../utils');

var _client = require('../../model/client/client');

var _client2 = _interopRequireDefault(_client);

var _clientDetails = require('../../model/client/clientDetails');

var _clientDetails2 = _interopRequireDefault(_clientDetails);

var _cleaner = require('../../model/cleaner/cleaner');

var _cleaner2 = _interopRequireDefault(_cleaner);

var _cleanerDetails = require('../../model/cleaner/cleanerDetails');

var _cleanerDetails2 = _interopRequireDefault(_cleanerDetails);

var _clientWallet = require('../../model/client/clientWallet');

var _clientWallet2 = _interopRequireDefault(_clientWallet);

var _allTransactions = require('../../model/allTransactions');

var _allTransactions2 = _interopRequireDefault(_allTransactions);

var _cleaningSchedule = require('../../model/cleaningSchedule');

var _cleaningSchedule2 = _interopRequireDefault(_cleaningSchedule);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var stripe = require('stripe')(_config2.default.stripeSectretKey);

// let Client =  require('../../models/client');
// let ClientDetails =  require('../../models/clientDetails');
// let Cleaner =  require('../../models/cleaner');
// let CleanerDetails =  require('../../models/cleanerDetails');
// let ClientWallet =  require('../../models/clientWallet');
// let Transactions =  require('../../models/allTransactions');
// let CleaningSchedule = require('../../models/cleaningSchedule');

exports.default = function (_ref) {
    var config = _ref.config,
        db = _ref.db;

    var api = (0, _express.Router)();

    // client Dashboard Route
    // 'api/v1/client/dashboard/:id'
    // api.get('/dashboard/:id', (req, res) => {
    //     Client.findById(req.params.id, (err, client) => {

    //         let query = {clientID: client.clientID};
    //         ClientDetails.find((query), (err, clientDetails) => {
    //             if (err) {
    //                 let result = {};
    //                 let status = 400;
    //                 let error = err;
    //                 result.status = status;
    //                 result.error = err;
    //                 res.status(status).send(result);
    //             }
    //             // res.render() --> can come here
    //             let status = 201;
    //             let result = {};
    //             let currentClient = client;
    //             let currentClientDetails = clientDetails[0];
    //             result.status = status;
    //             result.currentClient = currentClient;
    //             result.currentClientDetails = currentClientDetails;

    //             res.status(status).send(result);
    //         });
    //     });
    // });

    // api.post('/transaction', validateToken, (req, res)=>{
    //     console.log('form submitted');
    //     const clientID = req.body.clientID;
    //     const clientName = req.body.clientName;
    //     const cleanerID = req.body.cleanerID;
    //     const cleanDate = req.body.cleanDate;
    //     const totalPay = req.body.totalPay;
    //     const clientQuery = {clientID: clientID};
    //     Client.findOne((clientQuery), (err, clients)=>{
    //         var mainID = clients._id;
    //         Cleaner.findById(cleanerID, (err, mainCleaner)=>{
    //           console.log(mainCleaner);
    //             let walletUpdate = {};
    //             var pendingPay = [];
    //             let cleanerIDForQuery = mainCleaner.cleanerID;
    //             walletUpdate.pendingPay = pendingPay;
    //             let walletQuery = {pendingPay:[{cleanerID: cleanerID}]};
    //             //Update Client Wallet and Set Pending Pay to empty
    //             ClientWallet.updateOne(walletQuery, walletUpdate, (err, updWallet)=>{
    //                 var queryCleaner = {cleanerID: cleanerIDForQuery};
    //                 // Get Cleaner Details
    //                 CleanerDetails.findOne((queryCleaner), (err, cleanerDetails)=>{
    //                     console.log(cleanerDetails.fullName);
    //                     cleanerName = cleanerDetails.fullName
    //                     req.checkBody('clientID', 'clientID is required').notEmpty();
    //                     req.checkBody('clientName', 'clientName is required').notEmpty();
    //                     req.checkBody('cleanerID', 'clientPhone is required').notEmpty();
    //                     req.checkBody('cleanDate', 'Date is required').notEmpty();
    //                     req.checkBody('totalPay', 'totalPay is required').notEmpty();
    //
    //                     let errors = req.validationErrors();
    //                     if(errors){
    //                         console.log(errors)
    //                     }else{
    //                         let scheduleQuery = {cleanerID: cleanerID};
    //                         let scheduleUpdate = {};
    //                         var newStatus = {
    //                             paidStatus: true
    //                         }
    //                         scheduleUpdate.lastClean = newStatus;
    //                         CleaningSchedule.updateOne(scheduleQuery, scheduleUpdate, (err, schedule)=>{
    //                             //console.log(schedule.lastClean[0].lastCleanDate);
    //                             if(err){
    //                                 let result = {};
    //                                 let statusCode = 400;
    //                                 result.statusCode = statusCode;
    //                                 result.error = err;
    //                                 res.status(statusCode).send(result);
    //                                 console.log(err)
    //                             }else{
    //                                 let newTransaction = new Transactions({
    //                                     clientID: clientID,
    //                                     clientName: clientName,
    //                                     cleanerID: cleanerID,
    //                                     cleanerName: cleanerName,
    //                                     Date: cleanDate,
    //                                     totalPaid: totalPay,
    //                                 });
    //
    //                                 newTransaction.save((err) =>{
    //                                     let result = {};
    //                                     let statusCode = 200;
    //                                     if (err) {
    //                                         statusCode = 400;
    //                                         result.statusCode = statusCode;
    //                                         result.error = err;
    //                                         res.status(statusCode).send(result);
    //                                     }
    //                                         result.message = 'Transaction Completed';
    //                                         result.statusCode = statusCode;
    //                                         result.userID = mainID
    //                                         res.status(statusCode).send(result);
    //                                 });
    //                             }
    //                         })
    //                     }
    //                 })
    //             })
    //         })
    //     })
    // });

    api.post('/transaction', _utils.validateToken, function (req, res) {
        console.log('form submitted');
        var clientID = req.body.clientID;
        var clientName = req.body.clientName;
        var cleanerID = req.body.cleanerID;
        var cleanDate = req.body.cleanDate;
        var totalPay = req.body.totalPay;
        var clientQuery = { clientID: clientID };
        _client2.default.findOne(clientQuery, function (err, clients) {
            var mainID = clients._id;
            _cleaner2.default.findById(cleanerID, function (err, mainCleaner) {
                var walletUpdate = {};
                var pendingPay = [];
                walletUpdate.pendingPay = pendingPay;
                var walletQuery = { pendingPay: [{ cleanerID: cleanerID }] };
                //Update Client Wallet and Set Pending Pay to empty
                _clientWallet2.default.updateOne(walletQuery, walletUpdate, function (err, updWallet) {
                    var queryCleaner = { cleanerID: cleanerID };
                    // Get Cleaner Details
                    _cleanerDetails2.default.findOne(queryCleaner, function (err, cleanerDetails) {
                        console.log(cleanerDetails.fullName);
                        var cleanerName = cleanerDetails.fullName;
                        req.checkBody('clientID', 'clientID is required').notEmpty();
                        req.checkBody('clientName', 'clientName is required').notEmpty();
                        req.checkBody('cleanerID', 'clientPhone is required').notEmpty();
                        req.checkBody('cleanDate', 'Date is required').notEmpty();
                        req.checkBody('totalPay', 'totalPay is required').notEmpty();

                        var errors = req.validationErrors();
                        var result = {};
                        var statusCode = 400;
                        if (errors) {
                            result.statusCode = statusCode;
                            result.error = errors;
                            res.status(statusCode).send(result);
                            console.log(errors);
                        } else {
                            var scheduleQuery = { cleanerID: cleanerID };
                            var scheduleUpdate = {};
                            var newStatus = {
                                paidStatus: true
                            };
                            scheduleUpdate.lastClean = newStatus;
                            _cleaningSchedule2.default.updateOne(scheduleQuery, scheduleUpdate, function (err, schedule) {
                                //console.log(schedule.lastClean[0].lastCleanDate);
                                if (err) {
                                    console.log(err);
                                } else {
                                    var newTransaction = new _allTransactions2.default({
                                        clientID: clientID,
                                        clientName: clientName,
                                        cleanerID: cleanerID,
                                        cleanerName: cleanerName,
                                        Date: cleanDate,
                                        totalPaid: totalPay
                                    });

                                    newTransaction.save(function (err) {
                                        var result = {};
                                        var statusCode = 200;
                                        if (err) {
                                            statusCode = 404;
                                            result.statusCode = statusCode;
                                            result.error = err;
                                            res.status(statusCode).send(result);
                                        } else {
                                            result.message = 'Transaction Completed';
                                            result.statusCode = statusCode;
                                            result.userID = mainID;
                                            res.status(statusCode).send(result);
                                        }
                                    });
                                }
                            });
                        }
                    });
                });
            });
        });
    });

    //     api.post('/transaction', (req, res)=>{
    //     console.log('form submitted');
    //     const clientID = req.body.clientID;
    //     const clientName = req.body.clientName;
    //     const cleanerID = req.body.cleanerID;
    //     const cleanDate = req.body.cleanDate;
    //     const totalPay = req.body.totalPay;
    //     let clientQuery = {clientID: clientID};
    //     Client.findOne((clientQuery), (err, clients)=>{
    //         var mainID = clients._id;
    //         Cleaner.findById(cleanerID, (err, mainCleaner)=>{
    //           console.log( `The way to go ${mainCleaner}`);
    //             let walletUpdate = {};
    //             var pendingPay = [];
    //             walletUpdate.pendingPay = pendingPay;
    //             let walletQuery = {pendingPay:[{cleanerID: cleanerID}]};
    //             //Update Client Wallet and Set Pending Pay to empty
    //             ClientWallet.updateOne(walletQuery, walletUpdate, (err, updWallet)=>{
    //                 var queryCleaner = {cleanerID: mainCleaner.cleanerID};
    //                 // Get Cleaner Details
    //                 CleanerDetails.findOne((queryCleaner), (err, cleanerDetails)=>{
    //                     console.log(cleanerDetails.fullName);
    //                     cleanerName = cleanerDetails.fullName
    //                     req.checkBody('clientID', 'clientID is required').notEmpty();
    //                     req.checkBody('clientName', 'clientName is required').notEmpty();
    //                     req.checkBody('cleanerID', 'clientPhone is required').notEmpty();
    //                     req.checkBody('cleanDate', 'Date is required').notEmpty();
    //                     req.checkBody('totalPay', 'totalPay is required').notEmpty();
    //
    //                     let errors = req.validationErrors();
    //                     if(errors){
    //                         let result = {};
    //                         let statusCode = 400;
    //                         result.statusCode = statusCode;
    //                         result.error = errors;
    //                         res.status(statusCode).send(result);
    //                         // console.log(err)
    //                         // console.log(errors)
    //                     }else{
    //                         let scheduleQuery = {cleanerID: cleanerID};
    //                         let scheduleUpdate = {};
    //                         var newStatus = {
    //                             paidStatus: true
    //                         }
    //                         scheduleUpdate.lastClean = newStatus;
    //                         CleaningSchedule.updateOne(scheduleQuery, scheduleUpdate, (err, schedule)=>{
    //                             //console.log(schedule.lastClean[0].lastCleanDate);
    //                             if(err){
    //                                 console.log(err)
    //                             }else{
    //                                 let newTransaction = new Transactions({
    //                                     clientID: clientID,
    //                                     clientName: clientName,
    //                                     cleanerID: cleanerID,
    //                                     cleanerName: cleanerName,
    //                                     Date: cleanDate,
    //                                     totalPaid: totalPay,
    //                                 });
    //
    //                                 newTransaction.save((err) =>{
    //                                     let result = {};
    //                                     let statusCode = 200;
    //                                     if(err){
    //                                         statusCode = 400;
    //                                         result.statusCode = statusCode;
    //                                         result.error = err;
    //                                         res.status(statusCode).send(result);
    //
    //                                     }else {
    //                                         result.message = 'Transaction Completed';
    //                                         result.statusCode = statusCode;
    //                                         result.userID = mainID
    //                                         res.status(statusCode).send(result);
    //                                     }
    //                                 });
    //                             }
    //                         })
    //                     }
    //                 })
    //             })
    //         })
    //     })
    // });

    // payment success
    api.get('/:clientID', function (req, res) {
        var clientID = req.params.clientID;
        var revisit = true;
        var result = {
            'statusCode': 200,
            'revisit': revisit,
            'clientID': clientID
        };

        res.status(result.statusCode).send(result);
    });

    api.get('/bookingFinal/:clientID', _utils.validateToken, function (req, res) {
        // res.render('booking_final');
        // var ID = req.params.client;
        // console.log(ID);
        //var query1 = {clientID: ID};
        _client2.default.findOne({ clientID: req.params.clientID }, function (err, client) {
            console.log(client);
            var result = {};
            var statusCode = 200;
            _clientDetails2.default.findOne({ clientID: req.params.clientID }, function (err, client_details) {
                console.log(client_details.city);
                var query2 = { city: client_details.city };
                _cleanerDetails2.default.find(query2, function (err, cleanerDetails) {
                    if ((0, _isEmpty2.default)(cleanerDetails)) {
                        result.statusCode = statusCode;
                        result.user = client;
                        result.userDetails = client_details;
                        res.status(statusCode).send(result);
                    } else {
                        result.statusCode = statusCode;
                        result.user = client;
                        result.cleaner_details = cleanerDetails;
                        result.userDetails = client_details;
                        res.status(statusCode).send(result);

                        //console.log(cleanerDetails);
                        // res.render('booking_final',{
                        //     client: client,
                        //     clientDetails: client_details,
                        //     cleanerDetails: cleanerDetails
                        // });
                    }
                });
            });
        });
    });

    api.post('/renewBooking/:clientID/:id', _utils.validateToken, function (req, res) {
        var client = {};
        client.bedrooms = req.body.bedrooms;
        //console.log(req.body.fullName);
        client.bathrooms = req.body.bathrooms;
        client.extraTasks = req.body.extraTasks;
        client.dateFirstClean = req.body.date;
        client.cleaningHours = req.body.hours;
        client.moreCleaningHours = req.body.more_hours;
        client.apartmentAccess = req.body.access_type;
        client.keyHiddenPin = req.body.keyHiddenPin;
        client.keySafePin = req.body.keySafePin;
        client.cleaningFrequency = req.body.schedule;
        var query = { clientID: req.params.clientID };
        console.log(query);
        console.log(req.params.clientID);

        _clientDetails2.default.updateOne(query, client, function (err) {
            var result = {};
            var statusCode = 200;
            if (err) {
                statusCode = 400;
                result.statusCode = statusCode;
                result.error = err;
                res.status(statusCode).send(result);
            }
            result.statusCode = statusCode;
            result.message = 'Found and updated';
            result.id = req.param.id;
            res.status(statusCode).send(result);
        });
    });

    api.post('/pay', _utils.validateToken, function (req, res) {

        var amount = req.body.totalPay * 100;

        stripe.customers.create({
            email: req.body.stripeEmail, // customer email
            source: req.body.stripeToken //token for the card
        }).then(function (customer) {
            return stripe.charges.create({
                // charge the customer
                amount: amount,
                description: 'Cleaning for a particular cleaner',
                currency: 'eur',
                customer: customer.id
            });
        }).then(function (charge) {
            return res.render('client/success', {
                clientID: req.body.clientID,
                clientName: req.body.clientName,
                cleanerID: req.body.cleanerID,
                cleanDate: req.body.cleanDate,
                totalPay: req.body.totalPay,
                revisit: false
            });
        }); //render the payment successful page
    });
    return api;
};
//# sourceMappingURL=client.js.map