'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _express = require('express');

var _bcryptjs = require('bcryptjs');

var _bcryptjs2 = _interopRequireDefault(_bcryptjs);

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _crypto = require('crypto');

var _crypto2 = _interopRequireDefault(_crypto);

var _multer = require('multer');

var _multer2 = _interopRequireDefault(_multer);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _jsonwebtoken = require('jsonwebtoken');

var _jsonwebtoken2 = _interopRequireDefault(_jsonwebtoken);

var _isEmpty = require('is-empty');

var _isEmpty2 = _interopRequireDefault(_isEmpty);

var _utils = require('../../utils');

var _config = require('../../config');

var _config2 = _interopRequireDefault(_config);

var _client = require('../../model/client/client');

var _client2 = _interopRequireDefault(_client);

var _clientDetails = require('../../model/client/clientDetails');

var _clientDetails2 = _interopRequireDefault(_clientDetails);

var _clientWallet = require('../../model/client/clientWallet');

var _clientWallet2 = _interopRequireDefault(_clientWallet);

var _cleaner = require('../../model/cleaner/cleaner');

var _cleaner2 = _interopRequireDefault(_cleaner);

var _cleanerDetails = require('../../model/cleaner/cleanerDetails');

var _cleanerDetails2 = _interopRequireDefault(_cleanerDetails);

var _requests = require('../../model/booking/requests');

var _requests2 = _interopRequireDefault(_requests);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
var mailgun = require("mailgun-js");
var DOMAIN = 'kvetsluzeb.com';
var api_key = '3896a986c536ba4c44b6278b43417c4a-2ae2c6f3-9188bee6';
var mg = mailgun({
  apiKey: api_key,
  domain: DOMAIN,
  host: 'api.eu.mailgun.net'
});

var AllTransactions = require('../../model/allTransactions');

exports.default = function (_ref) {
  var config = _ref.config,
      db = _ref.db;

  var api = (0, _express.Router)();

  // **************************************************************
  // ******* CLIENT AUTHENTICATION COUPLED WITH BOOKING ***********
  // **************************************************************

  //Booking and Sign up Processes
  // /api/v1/client/account/signup
  api.post('/signup', function (req, res) {
    // console.log('form submitted');

    var storage = _multer2.default.diskStorage({
      destination: './public/uploads/',
      filename: function filename(req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + _path2.default.extname(file.originalname));
      }
    });

    function checkFileType(files, cb) {
      // Allowed ext
      var filetypes = /jpeg|jpg|png|gif/;
      // Check ext
      var extname = filetypes.test(_path2.default.extname(files.originalname).toLowerCase());
      // Check mime
      var mimetype = filetypes.test(files.mimetype);

      if (mimetype && extname) {
        return cb(null, true);
      } else {
        cb('Error: Images and Documents Only!');
      }
    }
    // Initialise Upload
    var upload = (0, _multer2.default)({
      storage: storage,
      limits: {
        fileSize: 10000000
      },
      fileFilter: function fileFilter(req, file, cb) {
        checkFileType(file, cb);
      }
    }).single('profilePic');

    var statusCode = 200;
    var result = {};

    upload(req, res, function (err) {

      if (err) {
        statusCode = 500;
        var error = err;
        result.status = status;
        result.error = error;
        res.status(statusCode).send(result);
      } else {
        // const username = req.body.username.toLowerCase();
        var email = req.body.email.toLowerCase();
        var password = req.body.password;
        var password2 = req.body.password2;

        var postcode = req.body.postcode;
        var bedrooms = req.body.bedrooms;
        var bathrooms = req.body.bathrooms;
        var extraTasks = req.body.extraTasks;
        var hours = req.body.hours;
        var more_hours = req.body.more_hours;
        var priority = req.body.priority;
        var access_type = req.body.access_type;
        var keySafePin = req.body.keySafePin;
        var keyHiddenPin = req.body.keyHiddenPin;
        var schedule = req.body.schedule;
        var date = req.body.date;
        var fullName = req.body.fullname;
        var mobileNumber = req.body.mobilenumber;
        var address = req.body.address;
        var city = req.body.city;
        var country = req.body.country;
        var profilePic = req.file.filename;
        var clientID = _bcryptjs2.default.hashSync('fullName', 10);
        console.log(clientID);

        req.checkBody('email', 'Email is required').notEmpty();
        req.checkBody('email', 'Email is not valid').isEmail();
        req.checkBody('password', 'Password is required').notEmpty();
        req.checkBody('password2', 'Passwords do not match').equals(req.body.password);

        req.checkBody('postcode', 'Postcode is required').notEmpty();
        req.checkBody('bedrooms', 'Number of Bedrooms is required').notEmpty();
        req.checkBody('bedrooms', 'Number of bedrooms must be a number').isNumeric();
        req.checkBody('bathrooms', 'Number of bathrooms is required').notEmpty();
        req.checkBody('bathrooms', 'Number of bathrooms mnust be a number').isNumeric();
        req.checkBody('hours', 'Hours for cleaning is required').notEmpty();
        if (more_hours == 'more') {
          req.checkBody('more_hours', 'Extended Cleaning Hours is required').notEmpty();
        }
        req.checkBody('access_type', 'How cleaner would access your home cannot be empty').notEmpty();
        if (access_type == 'key_safe') {
          req.checkBody('keySafePin', 'Key Safe Pin is required').notEmpty();
        }
        if (access_type == 'key_hidden') {
          req.checkBody('keyHiddenPin', 'Key Hidden location is required').notEmpty();
        }
        req.checkBody('schedule', 'Schedule is required').notEmpty();
        req.checkBody('fullname', 'Your Full Name  is not valid').notEmpty();
        req.checkBody('mobilenumber', 'Mobile Number is required').notEmpty();
        req.checkBody('address', 'Addresss is required').notEmpty();
        req.checkBody('city', 'City is required').notEmpty();
        req.checkBody('country', 'Country is required').notEmpty();

        var errors = req.validationErrors();

        if (errors) {

          statusCode = 500;
          var _error = errors;
          result.status = statusCode;
          result.error = _error;
          res.status(statusCode).send(result);
        } else {
          var newUser = new _client2.default({
            email: email,
            password: password,
            clientID: clientID
          });
          var newUserDetails = new _clientDetails2.default({
            postcode: postcode,
            bedrooms: bedrooms,
            bathrooms: bathrooms,
            extraTasks: extraTasks,
            dateFirstClean: date,
            cleaningHours: hours,
            moreCleaningHours: more_hours,
            cleaningPriority: priority,
            apartmentAccess: access_type,
            keyHiddenPin: keyHiddenPin,
            keySafePin: keySafePin,
            cleaningFrequency: schedule,
            mobileNumber: mobileNumber,
            address: address,
            fullName: fullName,
            city: city,
            country: country,
            profilePic: profilePic,
            clientID: clientID
          });
          var newWallet = new _clientWallet2.default({
            clientID: clientID
          });

          _bcryptjs2.default.genSalt(10, function (err, salt) {
            _bcryptjs2.default.hash(newUser.password, salt, function (err, hash) {
              if (err) {
                statusCode = 500;
                var _error2 = err;
                result.status = status;
                result.error = _error2;
                res.status(statusCode).send(result);
                // console.log(err);
              }
              //console.log('bcrypt stage reached');
              newUser.password = hash;
              newUser.save(function (err) {
                if (err) {
                  statusCode = 500;
                  var _error3 = err;
                  result.status = statusCode;
                  result.error = _error3;
                  res.status(statusCode).send(result);
                } else {

                  newUserDetails.save(function (err) {
                    if (err) {
                      statusCode = 500;
                      var _error4 = err;
                      result.status = statusCode;
                      result.error = _error4;
                      res.status(statusCode).send(result);
                    } else {
                      newWallet.save(function (err) {
                        if (err) {
                          statusCode = 500;
                          var _error5 = err;
                          result.status = statusCode;
                          result.error = _error5;
                          res.status(statusCode).send(result);
                        } else {
                          statusCode = 200;
                          result.status = statusCode;
                          result.message = 'Client added';
                          result.userID = clientID;
                          res.status(statusCode).send(result);
                        }
                      });
                    }
                  });
                }
              });
            });
          });
        }
      }
    });
  });

  // /api/v1/client/account/signup
  api.post('/login', function (req, res) {
    var _req$body = req.body,
        email = _req$body.email,
        password = _req$body.password;


    var result = {};
    var status = 200;

    _client2.default.findOne({
      email: email
    }, function (err, user) {
      if (!err && user) {
        _bcryptjs2.default.compare(password, user.password).then(function (match) {
          if (match) {
            status = 200;

            var payload = {
              _id: user._id
            };
            var options = {
              expiresIn: '1d',
              issuer: 'http://relicinnova.com.ng'
            };
            var secret = config.secret;
            var token = _jsonwebtoken2.default.sign(payload, secret, options);

            result.token = token;
            result.status = status;
            result.result = user;
          } else {
            status = 401;
            result.status = status;
            result.error = 'Authentication error';
          }
          res.status(status).send(result);;
        }).catch(function (err) {
          status = 500;
          result.status = status;
          result.error = err;
          res.status(status).send(result);
        });
      } else {
        status = 404;
        result.status = status;
        result.error = err;
        res.status(status).send(result);
      }
    });
  });

  api.patch('/resetPassword/:token', function (req, res) {

    // get user based on the token
    var hashedToken = _crypto2.default.createHash('sha256').update(req.params.token).digest('hex');

    // const user =
    _client2.default.findOne({
      passwordResetToken: hashedToken,
      passwordResetExpires: {
        $gt: Date.now()
      }
    }, function (err, user) {
      if (err) {
        res.status(404).send(err);
      }

      user.password = req.body.password;
      user.password2 = req.body.password2;
      user.passwordResetToken = undefined;
      user.passwordResetExpires = undefined;

      user.save(function (err) {
        if (err) {
          res.status(200).send(err);
        }
        res.status(201).json({
          message: 'Successful'
        });
      });
      //  Redirect the user to login
    });
    // if token has not expired and user exists we set the new password
  });

  api.patch('/passwordUpdate/:id', _utils.validateToken, function (req, res) {
    // get user from collection
    _client2.default.findById(req.id, function (err, user) {
      if (err) {
        res.send(err);
      } else if (!user.correctPassword(req.body.passwordCurrent, user.password)) {
        res.status(404).send('Your current password is wrong.');
      }
    });
    user.password = req.body.password;
    user.passwordConfirm = req.body.passwordConfirm;

    user.save(function (err) {
      if (err) {
        res.status(404).send(err);
      }
      res.status(201).json({
        message: 'Successfull'
      });
    });
  });

  // /api/v1/client/account/forgotPassword
  api.post('/forgotPassword', function (req, res) {
    // get user based on posted email
    _client2.default.findOne({
      email: req.body.email
    }, function (err, user) {

      var status = 200;
      var result = {};

      // console.log(req.body.email);
      if (err) {
        status = 404;
        result.status = status;
        result.error = err;
        res.status(status).send(result);
      }
      // generate random token

      var resetToken = user.createPasswordResetToken();
      // await user.save()
      user.save({
        validateBeforeSave: false
      });

      var resetUrl = req.protocol + '://' + req.get('host') + '/client/pswd/resetpswd/' + resetToken;
      var msg = '<strong>Forgot Password?</strong> Please click this link and enter your new password: ' + resetUrl + '.\n If you didnt forget your password, please ignore this email!';
      var data = {
        from: 'Kvet Sluzeb (Bloom Services) <support@kvetsluzeb.com>',
        to: req.body.email,
        subject: 'Password Reset Token',
        text: msg,
        html: msg
      };
      mg.messages().send(data, function (error, body) {
        if (error) {
          // console.log(error)
          status = 404;
          result.status = status;
          result.error = error;
          // result.message = ''
          res.status(status).send(result);
          //   res.render('client/forgotpswd', {
          //     clientID: user._id,
          //     message: 'Please make sure you entered the right password'
          // })
        } else {
          status = 200;
          result.status = status;
          result.message = 'The password reset token has been sent to your mail';
          // result.message = ''
          res.status(status).send(result);
        }
      });
    });
  });

  api.post('/passwordChange/:id', _utils.validateToken, function (req, res) {
    // get user from collection
    _client2.default.findById(req.params.id, function (err, user) {
      var result = {};
      var status = 200;
      if (err) {
        status = 404;
        result.status = status;
        result.error = err;
        res.status(status).send(result);
        return;
      } else {
        //Check Old Password
        _bcryptjs2.default.compare(req.body.passwordCurrent, user.password, function (err, match) {
          if (!match) {
            status = 400;
            result.status = status;
            result.message = 'Your current password is incorrect. Please try again';
            res.status(status).send(result);
          } else {
            //Password Match
            var password = req.body.password;
            var passwordConfirm = req.body.passwordConfirm;
            // console.log(password, passwordConfirm);
            req.checkBody('password', 'Password is required').notEmpty();
            req.checkBody('passwordConfirm', 'Passwords do not match').equals(req.body.password);
            var errors = req.validationErrors();

            if (errors) {
              status = 400;
              result.status = status;
              result.error = errors;
              res.status(status).send(result);

              return;
            } else {
              user.password = password;
              // user.passwordConfirm = passwordConfirm;
              _bcryptjs2.default.genSalt(10, function (err, salt) {
                _bcryptjs2.default.hash(user.password, salt, function (err, hash) {
                  if (err) {
                    status = 500;
                    result.status = status;
                    result.error = err;
                    res.status(status).send(result);
                  }
                  user.password = hash;
                  user.save(function (err) {
                    if (err) {
                      status = 400;
                      result.status = status;
                      result.error = err;
                      res.status(status).send(result);
                    } else {
                      status = 201;
                      result.status = status;
                      result.message = 'Password updated Successfully';
                      res.status(status).send(result);
                    }
                  });
                });
              });
            }
          }
        });
      }
    });
  });

  // '/api/v1/client/account/logout' --> not working
  api.get('/logout', _utils.validateToken, function (req, res) {
    res.logout();
    var result = {};
    var status = 201;
    var message = 'Successfully Logged out';
    result.status = status;
    result.message = message;
    res.status(status).send(result);
  });

  // ********************************************
  // ******* CLEANER PROFILE SETTINGS ***********
  // ********************************************

  api.post('/profile/:clientID/:id', _utils.validateToken, function (req, res) {
    var statusCode = 200;
    var result = {};

    var client = {};
    client.fullName = req.body.fullName;
    console.log(req.body.fullName);
    client.postcode = req.body.postcode;
    client.city = req.body.city;
    client.country = req.body.country;
    client.address = req.body.address;
    client.mobileNumber = req.body.mobileNumber;
    var query = {
      clientID: req.params.clientID
    };
    console.log(query);
    console.log(req.params.clientID);

    _clientDetails2.default.updateOne(query, client, function (err) {
      if (err) {
        result.statusCode = 401;
        result.error = err;
        res.status(statusCode).send(result);
      } else {
        result.statusCode = statusCode;
        result.message = 'found and updated';
        res.status(statusCode).send(result);
        // res.redirect('/client/dashboard/home/'+req.params.id);
      }
    });
  });

  // ************************************
  // ******* CLIENT DARSHBOARD ***********
  // *************************************


  api.get('/home/:id', _utils.validateToken, function (req, res) {
    _client2.default.findById(req.params.id, function (err, client) {
      //console.log(client)
      var query = {
        clientID: client.clientID
      };
      _clientDetails2.default.find(query, function (err, client_details) {
        var result = {};
        var statusCode = 201;

        if (err) {
          result.status = 404;
          result.error = err;
          res.status(statusCode).send(result);
        }
        result.statusCode = statusCode;
        result.user = client_details[0];
        res.status(statusCode).send(result);
      });
    });
  });

   // ************************************
  // ******* CLIENT DARSHBOARD (THIS PAGE WOULD
  // SHOW THE CLEANER THAT HAS ACCEPTED THE REQUEST)***********
  // *************************************

  api.get('/dashboard/:id', _utils.validateToken, function (req, res){
    _client2.default.findById(req.params.id, function (err, client){
      var query  = {clientID: client.clientID};
      _clientDetails2.default.find(query, function(err, client_details){
        _requests2.default.find(query, function(err, request){
          var result = {};
          var statusCode = 201;
          var accepted;
          if (err) {
            result.status = 404;
            result.error = err;
            res.status(statusCode).send(result);
          }

          if(request[0].status == false){
            accepted = false;
            result.accepted = accepted;
            result.statusCode = statusCode;
            result.user = client_details[0];
            res.status(statusCode).send(result);
          }else{
            accepted = true;
            var cleanerID = request[0].confirmedCleanerID
            var queryClean = {cleanerID: cleanerID};
            _cleanerDetails2.default.find(queryClean, function(err, cleaner_details){
              result.accepted = accepted;
              result.cleaner = cleaner_details;
              result.statusCode = statusCode;
              result.user = client_details[0];
              res.status(statusCode).send(result);
            })
          }
        })
      })
    })
  })

  api.get('/wallet/:id', _utils.validateToken, function (req, res) {
    _client2.default.findById(req.params.id, function (err, client) {
      //console.log(client)
      var result = {};
      var statusCode = 200;

      var query = {
        clientID: client.clientID
      };
      _clientDetails2.default.find(query, function (err, client_details) {
        //console.log(client_details[0]);
        _clientWallet2.default.findOne(query, function (err, clientWallet) {
          var pending;
          var costStatus = false;
          if ((0, _isEmpty2.default)(clientWallet.pendingPay)) {
            costStatus = true;
            pending = true;
            console.log('pending pay is empty');
          } else {
            if ((0, _isEmpty2.default)(clientWallet.pendingPay[0].cost)) {
              costStatus = true;
              //pending = false;
              console.log('cost Status is empty');
            }
            pending = false;
            //costStatus = false;
            console.log('pending pay is not empty ', clientWallet.pendingPay[0].cost, ' ', costStatus);
          }

          result.statusCode = statusCode;
          result.user = client;
          result.wallet = clientWallet;
          result.costStatus = costStatus;
          result.pending = pending;
          result.stripeKey = result.userDetails = client_details[0];
          // result.wallet = wallet;
          result.StripePublishableKey = config.StripePublishableKey;
          res.status(statusCode).send(result);
        });
      });
    });
  });

  api.get('/transactions/:id', _utils.validateToken, function (req, res) {
    _client2.default.findById(req.params.id, function (err, client) {
      //console.log(client)
      var result = {};
      var statusCode = 200;

      var query = {
        clientID: client.clientID
      };
      _clientDetails2.default.find(query, function (err, client_details) {
        //console.log(client_details[0]);
        AllTransactions.find(query, function (err, transactions) {
          var noTransaction = false;
          if ((0, _isEmpty2.default)(transactions)) {
            noTransaction = true;
          }

          result.statusCode = statusCode;
          result.user = client;
          result.userDetails = client_details[0];
          result.transactions = transactions;
          result.transactionStatus = noTransaction;
          res.status(statusCode).send(result);
          // console.log(transactions[0].cleaner);
        });
      });
    });
  });

  api.get('/clientFaq/:id', _utils.validateToken, function (req, res) {
    _client2.default.findById(req.params.id, function (err, client) {
      //console.log(client)

      var query = {
        clientID: client.clientID
      };
      _clientDetails2.default.find(query, function (err, client_details) {
        //console.log(client_details[0]);
        var result = {};
        var statusCode = 200;
        if (err) {
          statusCode = 400;
          result.statusCode = statusCode;
          result.error = err;
          res.status(statusCode).send(result);
        }
        result.user = client;
        result.userDetails = client_details[0];
        result.statusCode = statusCode;
        res.status(statusCode).send(result);
      });
    });
  });

  api.get('/renew/:id', _utils.validateToken, function (req, res) {
    _client2.default.findById(req.params.id, function (err, client) {
      //console.log(client)
      var query = {
        clientID: client.clientID
      };
      _clientDetails2.default.find(query, function (err, client_details) {
        //console.log(client_details[0]);
        var result = {};
        var statusCode = 200;
        if (err) {
          statusCode = 400;
          result.statusCode = statusCode;
          result.error = err;
          res.status(statusCode).send(result);
        }
        result.user = client;
        result.userDetails = client_details[0];
        result.statusCode = statusCode;
        res.status(statusCode).send(result);
      });
    });
  });

  // **********************************************
  // ******* CANCEL CLEANING SCHEDULE *************
  // **********************************************
  api.get('/:scheduleID/:cleanerID/:clientID', function (req, res) {
    const {scheduleID, cleanerID, clientID} = req.params;
    var result = {};
    var statusCode = 200;
    _cleaningSchedule2.default
        .findById(scheduleID)
        .populate('clientDetails')
        .exec((err, schedule)=>{
        if(err){
            console.log(err)
        }
        else{
          let cancelUpdate = {};
          var dblastClean = schedule.lastClean[0];
          var dbcurrentClean = schedule.currentClean[0];
          var incremental = schedule.currentClean[0].incremental;
          var newCurrentDate = schedule.currentClean[0].nextCleanDate;
          var nextCleanDate = new Date().setDate(newCurrentDate.getDate() + incremental);
          var nextCleanDate = new Date(nextCleanDate);
          var clientName = schedule.clientDetails[0].fullName;
          var mailDate = new Date(dbcurrentClean.currentCleanDate);
          var mailDate = date.format(mailDate, 'ddd, MMM DD YYYY');
          // console.log(schedule.clientDetails[0].email)
          var query = {cleanerID: cleanerID};
          _cleanerDetails2.default.find((query), (err, cleanerDetails)=>{
            var cleanerMail = cleanerDetails[0].email;
            var msg = `<strong>Your cleaning Schedule has just been cancelled</strong> by your client ${clientName} for ${mailDate}. Please contact this client for clarity on this change of plans and for a reschedule. Sorry for the inconvenience. <br/> Regards. Kvet Sluzeb Team`
            var data = {
              from: 'Kvet Sluzeb <info@kvetsluzeb.com>',
              to: cleanerMail,
              subject: 'Schedule Changes',
              text: msg,
              html: msg
            };
            mg.messages().send(data, function (error, body) {
                if(error){
                    console.log(error);
                }
                else{
                    var lastClean = [{
                        cleanStatus : false,
                        paidStatus : false,
                        cancelStatus : true,
                        lastCleanDate  : dbcurrentClean.currentCleanDate
                    }];
                    var currentClean = [{
                            cleanStatus : true,
                            paidStatus : false,
                            cancelStatus : false,
                            currentCleanDate  : newCurrentDate,
                            nextCleanDate: nextCleanDate,
                            incremental: incremental
                    }]
                    //console.log(lastClean, ' ', currentClean);
                    cancelUpdate.lastClean = lastClean;
                    cancelUpdate.currentClean = currentClean;
                    var newLastCleanDate = dbcurrentClean.currentCleanDate;
                    console.log(newLastCleanDate);
                    var query = {_id: scheduleID};
                    _cleaningSchedule2.default.updateOne(query, cancelUpdate, (err) =>{
                        if (err) {
                          result.error = err;
                          result.statusCode = 404;
                          res.status(statusCode).send(result);
                        } else {
                          var message = 'Schedule Canceled succesfully. Please redirect to User dashboard';
                          result.error = err;
                          result.statusCode = statusCode;
                          result.message = message;
                          res.status(statusCode).send(result);
                        }
                    });
                }
            });
          })
        }
    });
  });

  // **********************************************
  // ******* RATE A CLEANER *************
  // **********************************************
  api.get('/rate/cleaner/:clientID/:cleanerID/', function (req, res){
    let cleaner = {};
    cleaner.rating = req.body.rating;
    let query = {cleanerID : req.params.cleanerID}

    _cleanerDetails2.default.updateOne(query, cleaner, (err)=>{
      if (err) {
        result.error = err;
        result.statusCode = 404;
        res.status(statusCode).send(result);
      } else {
        var message = 'Cleaner Rated';
        result.error = err;
        result.statusCode = statusCode;
        result.message = message;
        res.status(statusCode).send(result);
      }
    })
  })


  return api;
};
//# sourceMappingURL=account.js.map